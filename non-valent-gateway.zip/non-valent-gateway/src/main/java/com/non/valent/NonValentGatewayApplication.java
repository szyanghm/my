package com.non.valent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NonValentGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(NonValentGatewayApplication.class, args);
	}

}
