package com.non.valent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NonValentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
