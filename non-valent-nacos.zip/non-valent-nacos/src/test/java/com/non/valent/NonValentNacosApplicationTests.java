package com.non.valent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NonValentNacosApplicationTests {

	@Test
	void contextLoads() {
	}

}
