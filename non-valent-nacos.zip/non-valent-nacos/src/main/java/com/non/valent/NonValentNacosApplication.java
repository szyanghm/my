package com.non.valent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NonValentNacosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NonValentNacosApplication.class, args);
	}

}
