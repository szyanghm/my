package com.non.valent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NonValentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NonValentServiceApplication.class, args);
	}

}
